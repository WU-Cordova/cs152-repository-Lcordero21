
#!/usr/bin/env python
import os
# Windows
from time import sleep
import time
if os.name == 'nt':
    import msvcrt
# Posix (Linux, OS X)
class KBHit:
    def __init__(self):
        '''Creates a KBHit object that you can call to do various keyboard things.
        '''
        if os.name == 'nt':
            pass

    def set_normal_term(self):
        ''' Resets to normal terminal. On Windows this is a no-op.
        '''
        if os.name == 'nt':
            pass

    def getch(self):
        ''' Returns a keyboard character after kbhit() has been called.
        Should not be called in the same program as getarrow().
        '''
        s = ''
        if os.name == 'nt':
            return msvcrt.getch().decode('utf-8')

    def getarrow(self):
        ''' Returns an arrow-key code after kbhit() has been called. Codes are
        0 : up
        1 : right
        2 : down
        3 : left
        Should not be called in the same program as getch().
        '''
        if os.name == 'nt':
            msvcrt.getch() # skip 0xE0
            c = msvcrt.getch()
            vals = [72, 77, 80, 75]

    def kbhit(self):
        ''' Returns True if keyboard character was hit, False otherwise.
        '''
        if os.name == 'nt':
            return msvcrt.kbhit()

# Test
if __name__ == "__main__":
    kb = KBHit()
    print('Hit any key, or ESC to exit')
    iteration = 0
    while True:
        print(f'In loop: {iteration}')
        iteration += 1
        time.sleep(1)
        if kb.kbhit():
            c = (kb.getch())
            c_ord = ord(c)
            print(c)
            print(c_ord)
            time.sleep(2)
            if c_ord == 27: # ESC
                break
            print(c)
        kb.set_normal_term()