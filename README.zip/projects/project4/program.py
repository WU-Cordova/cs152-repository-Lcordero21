

def main():
    Col1=["MATH251", "CS152", "DATA331"]
    Col2 = ["MATH251"]
    majorReq = []

    if isinstance (Col1, Col2):
        majorReq.append()

    print(majorReq)


if __name__ == '__main__':
    main()
