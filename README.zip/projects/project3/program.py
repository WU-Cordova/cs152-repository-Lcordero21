

def main():
    def is_prime (n):
        while True:
            num = n*2
            for i in range (2,(num ** 0.5)):
                if (num % i) == 0:
                    num+=1
                    



if __name__ == '__main__':
    main()
