from enum import Enum

class CharacterType(Enum):
    WARRIOR= "Warrior"
    MAGE= "Mage"
    ROGUE= "Rogue"